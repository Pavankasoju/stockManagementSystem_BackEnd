package com.abridged.stock_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
