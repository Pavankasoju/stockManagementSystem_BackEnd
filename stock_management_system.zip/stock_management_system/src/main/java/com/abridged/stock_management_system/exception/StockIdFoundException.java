package com.abridged.stock_management_system.exception;

/**
 * This is StockIdFoundException Class
 * 
 * @author 
 */
public class StockIdFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
