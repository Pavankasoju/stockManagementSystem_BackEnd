package com.abridged.stock_management_system.exception;

/**
 * This is InvestorIdFoundException Class
 * 
 * @author 
 */
public class InvestorIdFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
