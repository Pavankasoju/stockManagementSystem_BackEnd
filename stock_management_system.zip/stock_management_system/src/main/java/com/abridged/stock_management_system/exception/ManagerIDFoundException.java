package com.abridged.stock_management_system.exception;

/**
 * This is ManagerIDFoundException Class
 * 
 * @author
 */
public class ManagerIDFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
